/*
 Navicat Premium Data Transfer

 Source Server         : 172.31.179.131
 Source Server Type    : MySQL
 Source Server Version : 80027
 Source Host           : 172.31.179.131:53306
 Source Schema         : test_data

 Target Server Type    : MySQL
 Target Server Version : 80027
 File Encoding         : 65001

 Date: 24/02/2025 11:46:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ChargingStation
-- ----------------------------
DROP TABLE IF EXISTS `ChargingStation`;
CREATE TABLE `ChargingStation` (
  `dtime` datetime NOT NULL COMMENT '时间',
  `chongqing` int DEFAULT NULL COMMENT '公共类充电桩数量_重庆',
  `beijing` int DEFAULT NULL COMMENT '公共类充电桩数量_北京',
  `guangdong` int DEFAULT NULL COMMENT '公共类充电桩数量_广东',
  `shanghai` int DEFAULT NULL COMMENT '公共类充电桩数量_上海',
  `zhejiang` int DEFAULT NULL COMMENT '公共类充电桩数量_浙江',
  `anhui` int DEFAULT NULL COMMENT '公共类充电桩数量_安徽',
  `tianjin` int DEFAULT NULL COMMENT '公共类充电桩数量_天津',
  `sichuan` int DEFAULT NULL COMMENT '公共类充电桩数量_四川',
  `shandong` int DEFAULT NULL COMMENT '公共类充电桩数量_山东',
  `jiangsu` int DEFAULT NULL COMMENT '公共类充电桩数量_江苏',
  `zlz` int DEFAULT NULL COMMENT '公共类充电桩数量_直流桩_全国',
  `jlz` int DEFAULT NULL COMMENT '公共类充电桩数量_交流桩_全国'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='各省充电桩数量统计';

-- ----------------------------
-- Records of ChargingStation
-- ----------------------------
BEGIN;
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-07-31 00:00:00', 53691, 103673, 343595, 111772, 109989, 71127, 39042, 51072, 76002, 111510, 684000, 890000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-06-30 00:00:00', 31858, 103002, 330747, 110268, 105445, 68495, 38579, 49440, 73862, 109644, 665000, 863000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-05-31 00:00:00', 29923, 101907, 281202, 109072, 103354, 66832, 38110, 47199, 70825, 106531, 613000, 806000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-04-30 00:00:00', NULL, 100388, 241617, 107833, 97953, 65485, NULL, NULL, 68132, 102842, 577000, 755000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-03-31 00:00:00', NULL, 98432, 201302, 107218, 90843, 62943, NULL, NULL, 64188, 100923, 502000, 729000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-02-28 00:00:00', NULL, 98243, 199988, 106247, 89188, 61717, NULL, NULL, 62290, 100717, 496000, 717000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2022-01-31 00:00:00', NULL, 97526, 185649, 104579, 83978, 60858, NULL, NULL, 61539, 100015, 486000, 691000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-12-31 00:00:00', NULL, 96840, 181846, 103249, 82041, 58307, NULL, NULL, 60251, 97265, 470000, 677000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-11-30 00:00:00', NULL, 95301, 169348, 100464, 79907, 52397, NULL, NULL, 56727, 93769, 450000, 646000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-10-31 00:00:00', NULL, 94068, 165822, 97962, 76267, 49325, NULL, NULL, 56300, 91788, 436000, 626000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-09-30 00:00:00', NULL, 93604, 160961, 97269, 74466, 49555, NULL, NULL, 55058, 90424, 428000, 616000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-08-31 00:00:00', NULL, 90281, 151940, 95320, 70655, 44633, NULL, NULL, 53321, 86344, 399000, 586000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-07-31 00:00:00', NULL, 88018, 146849, 91465, 76475, 43213, NULL, NULL, 51229, 81305, 383000, 567000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-06-30 00:00:00', NULL, 84857, 143042, 89370, 66367, 42733, NULL, NULL, 51111, 79987, 374000, 550000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-05-31 00:00:00', NULL, 83407, 120986, 87734, 65221, 42385, NULL, NULL, 50309, 78739, 368000, 516000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-04-30 00:00:00', NULL, 82655, 119082, 85943, 64391, 41702, NULL, NULL, 50371, 77492, 363000, 505000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-03-31 00:00:00', NULL, 81869, 113797, 84987, 63647, 41137, 2357, NULL, 49886, 76586, 356000, 495000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-02-28 00:00:00', NULL, 81450, 112521, 84476, 62457, 39890, NULL, NULL, 49065, 75622, 349000, 488000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2021-01-31 00:00:00', NULL, 78933, 111226, 81382, 60762, 39273, NULL, NULL, 47012, 72165, 344000, 466000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-12-31 00:00:00', NULL, 87634, 85874, 85538, 61542, 38959, NULL, NULL, 48890, 77053, 309000, 498000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-11-30 00:00:00', NULL, 69607, 76051, 75256, 55990, 32715, NULL, NULL, 42537, 69171, 297000, 397000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-10-31 00:00:00', NULL, 67981, 73263, 73477, 52436, 31116, 22248, NULL, 39856, 67479, 291000, 376000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-09-30 00:00:00', NULL, 61017, 71950, 69506, 38776, 29325, NULL, NULL, 36058, 62934, 255000, 350000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-08-31 00:00:00', NULL, 60153, 70015, 68037, 37728, 28485, NULL, NULL, 35636, 62106, 250000, 341000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-07-31 00:00:00', NULL, 58887, 68265, 66514, 33815, 28281, NULL, NULL, 34752, 60909, 240000, 326000);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-06-30 00:00:00', NULL, 58135, 67197, 65298, 32929, 27851, NULL, NULL, 34349, 61300, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-05-31 00:00:00', NULL, 57182, 66058, 64491, 31529, 27432, NULL, NULL, 33750, 63709, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-04-30 00:00:00', NULL, 56261, 65407, 63973, 31088, 26607, NULL, NULL, 33471, 66683, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-03-31 00:00:00', NULL, 58865, 64522, 62951, 30576, 26159, NULL, NULL, 33379, 66137, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-02-29 00:00:00', NULL, 60829, 63507, 55156, 29653, 26487, NULL, NULL, 32797, 65827, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2020-01-31 00:00:00', NULL, 61036, 63645, 55358, 29715, 26470, NULL, NULL, 32516, 65707, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-12-31 00:00:00', 11245, 59060, 62834, 55113, 29138, 25754, 16687, 14150, 32130, 60509, 214670, 301238);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-11-30 00:00:00', NULL, 57202, 59678, 54279, 27964, 24261, 16264, NULL, 31571, 58665, NULL, NULL);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-10-31 00:00:00', 10961, 55089, 58019, 53938, 27048, 23198, 15319, 12170, 30643, 56927, 199793, 277851);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-09-30 00:00:00', 10963, 54301, 55416, 53311, 25994, 22981, 15076, 11816, 30421, 55652, 194524, 271028);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-08-31 00:00:00', 10760, 53743, 53248, 52090, 25099, 22458, 14872, 11467, 30609, 54494, 190188, 265071);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-07-31 00:00:00', 10812, 53018, 51718, 51530, 24638, 21745, 14644, 10904, 30550, 53315, 186587, 259504);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-06-30 00:00:00', 10292, 51774, 46753, 49581, 22825, 15235, 14741, 10017, 29974, 47330, 174652, 236418);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-05-31 00:00:00', 10104, 51778, 46258, 48629, 22025, 14840, 14742, 9987, 29797, 42004, 171162, 228980);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-04-30 00:00:00', 9851, 51188, 45217, 47772, 21576, 13992, 14695, 9608, 29343, 40656, 167556, 222923);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-03-31 00:00:00', 9505, 50694, 44672, 47044, 21098, 13065, 14735, 9278, 28303, 39902, 163967, 219053);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-02-28 00:00:00', 9255, 46862, 36034, 42415, 19604, 11404, 14156, 8182, 20059, 34919, 159058, 188015);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2019-01-31 00:00:00', 9352, 46137, 35890, 41726, 19450, 11021, 14021, 8034, 25799, 34502, 157127, 184083);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-12-31 00:00:00', 8538, 41644, 35928, 39303, 14226, 10228, 11209, 8169, 20798, 30333, 109393, 189814);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-11-30 00:00:00', 8537, 40584, 33973, 38141, 14053, 10089, 10849, 7885, 20947, 29571, 108251, 180935);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-10-31 00:00:00', 8512, 40241, 33960, 37069, 13900, 9727, 10633, 7737, 20820, 29019, 100685, 183421);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-09-30 00:00:00', 6820, 42126, 35581, 35929, 13331, 11003, 11644, 7092, 20653, 29183, 97138, 126398);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-08-31 00:00:00', 6644, 41646, 34628, 35310, 13199, 10965, 11700, 6930, 20288, 28954, 92871, 123295);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-07-31 00:00:00', 6581, 41130, 33937, 35007, 13090, 10968, 11657, 6838, 20128, 28464, 90482, 120713);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-06-30 00:00:00', 6394, 40865, 33586, 34773, 12909, 10870, 11661, 6701, 20139, 28378, 87956, 119445);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-05-31 00:00:00', 6306, 40663, 32701, 34313, 12759, 10757, 11555, 6337, 20316, 27586, 84174, 116761);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-04-30 00:00:00', 6149, 40184, 32693, 33666, 12734, 10782, 11422, 5915, 20282, 27152, 81492, 114472);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-03-31 00:00:00', 5974, 39505, 31370, 33200, 12356, 10710, 11317, 5639, 19937, 25348, 77437, 109584);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-02-28 00:00:00', 5873, 35869, 30755, 31866, 12181, 10644, 10660, 5580, 19602, 24769, 75922, 102048);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2018-01-31 00:00:00', 5043, 30805, 30083, 30149, 10288, 10228, 10146, 5284, 18210, 23184, 65947, 93065);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-12-31 00:00:00', 4949, 30363, 29262, 26314, 9866, 9909, 9788, 4731, 17557, 22075, 61375, 86469);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-11-30 00:00:00', 4629, 29731, 28309, 24462, 9497, 9729, 9431, 4581, 16831, 21376, 56936, 81734);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-10-31 00:00:00', 4429, 27309, 27136, 23874, 7966, 9565, 8937, 4362, 16553, 20694, 51776, 76759);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-09-30 00:00:00', 4249, 26990, 26340, 23516, 7804, 9495, 8626, 4276, 16210, 20417, 49717, 74783);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-08-31 00:00:00', 4045, 26673, 25907, 22609, 7604, 9254, 8425, 4125, 15855, 20174, 47736, 72194);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-07-31 00:00:00', 3807, 26265, 25201, 22016, 7336, 8805, 8350, 4019, 15378, 19698, 45646, 68978);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-06-30 00:00:00', 3638, 25150, 24185, 19602, 7059, 8367, 8224, 3913, 14982, 18496, 43212, 62337);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-05-31 00:00:00', 3549, 24730, 23739, 18914, 6814, 8208, 8116, 3804, 14449, 18038, 41275, 59597);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-04-30 00:00:00', 3340, 23991, 23271, 17871, 6408, 8066, 8014, 3696, 13939, 17512, 39163, 55956);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-03-31 00:00:00', 3050, 23375, 22795, 17323, 5943, 7790, 7787, 3570, 13448, 17251, 38757, 55117);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-02-28 00:00:00', 2767, 22748, 22297, 17303, 5542, 7370, 7060, 3461, 12990, 16999, 38490, 54919);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2017-01-31 00:00:00', 2571, 22579, 21994, 16967, 5433, 7115, 6972, 3396, 12719, 16696, 38421, 54443);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-12-31 00:00:00', 2362, 21940, 21108, 16444, 5246, 6756, 6782, 2986, 12340, 15869, 38096, 52778);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-11-30 00:00:00', 1837, 16589, 19575, 12340, 3179, 5773, 4717, 2929, 8038, 12683, 15699, 60269);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-10-31 00:00:00', 1671, 15287, 18542, 11690, 2639, 5422, 4304, 2736, 6945, 12196, 14965, 58286);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-09-30 00:00:00', 1558, 14508, 18201, 11261, 2476, 4953, 3940, 2563, 6560, 11715, 14774, 56838);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-08-31 00:00:00', 1463, 13988, 16538, 10487, 2118, 4864, 3419, 2248, 5551, 10798, 14363, 54621);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-07-31 00:00:00', 1334, 13071, 15425, 9915, 1895, 4559, 2937, 2122, 4873, 10277, 14082, 52920);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-06-30 00:00:00', 1258, 12322, 15164, 9628, 1795, 4516, 2785, 1971, 4648, 9289, 13468, 51835);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-05-31 00:00:00', 1042, 11570, 14759, 8252, 1701, 4432, 2670, 1904, 4506, 8816, 13118, 49639);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-04-30 00:00:00', 1002, 10875, 13656, 7221, 1567, 4320, 2553, 1904, 4345, 8370, 12803, 45997);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-03-31 00:00:00', 860, 10070, 12554, 6003, 1512, 4058, 2169, 1748, 4041, 7945, 12447, 42027);
INSERT INTO `ChargingStation` (`dtime`, `chongqing`, `beijing`, `guangdong`, `shanghai`, `zhejiang`, `anhui`, `tianjin`, `sichuan`, `shandong`, `jiangsu`, `zlz`, `jlz`) VALUES ('2016-02-29 00:00:00', 650, 9027, 11876, 5202, 1505, 3915, 2123, 1728, 3814, 7170, 12170, 39390);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
