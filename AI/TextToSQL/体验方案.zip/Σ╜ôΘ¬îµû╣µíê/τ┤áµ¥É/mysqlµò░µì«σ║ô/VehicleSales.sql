/*
 Navicat Premium Data Transfer

 Source Server         : 172.31.179.131
 Source Server Type    : MySQL
 Source Server Version : 80027
 Source Host           : 172.31.179.131:53306
 Source Schema         : test_data

 Target Server Type    : MySQL
 Target Server Version : 80027
 File Encoding         : 65001

 Date: 24/02/2025 11:47:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for VehicleSales
-- ----------------------------
DROP TABLE IF EXISTS `VehicleSales`;
CREATE TABLE `VehicleSales` (
  `dtime` datetime DEFAULT NULL COMMENT '时间',
  `neProdVol` double(20,6) DEFAULT NULL COMMENT '新能源汽车产量,万辆',
  `neSalesVol` double(20,6) DEFAULT NULL COMMENT '新能源汽车销量,万辆',
  `elecProdVol` double(20,6) DEFAULT NULL COMMENT '纯电动汽车产量,万辆',
  `elecSalesVol` double(20,6) DEFAULT NULL COMMENT '纯电动汽车销量,万辆',
  `hybProdVol` double(20,6) DEFAULT NULL COMMENT '插电式混合动力汽车产量,万辆',
  `hybSalesVol` double(20,6) DEFAULT NULL COMMENT '插电式混合动力汽车销量,万辆'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='新能源、纯电动、混合动力汽车销量统计';

-- ----------------------------
-- Records of VehicleSales
-- ----------------------------
BEGIN;
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-01-01 00:00:00', 0.688900, 0.568000, 0.585700, 0.497800, 0.103200, 0.070400);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-02-01 00:00:00', 1.797200, 1.759600, 1.532700, 1.391900, 0.264500, 0.367700);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-03-01 00:00:00', 3.301500, 3.112000, 2.668500, 2.534200, 0.633000, 0.577800);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-04-01 00:00:00', 3.730600, 3.436100, 3.019700, 2.857000, 0.710800, 0.579100);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-05-01 00:00:00', 5.144700, 4.530000, 4.361900, 3.853000, 0.782800, 0.677000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-06-01 00:00:00', 6.500000, 5.900000, 5.400000, 4.800000, 1.100000, 1.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-07-01 00:00:00', 5.900000, 5.600000, 4.300000, 4.400000, 1.200000, 1.200000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-08-01 00:00:00', 7.200000, 6.800000, 5.800000, 5.600000, 1.400000, 1.200000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-09-01 00:00:00', 7.700000, 7.800000, 6.400000, 6.400000, 1.300000, 1.400000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-10-01 00:00:00', 9.200000, 9.100000, 7.700000, 7.700000, 1.500000, 1.400000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-11-01 00:00:00', 12.200000, 11.900000, 10.500000, 10.200000, 1.700000, 1.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2017-12-01 00:00:00', 14.900000, 16.300000, 12.900000, 14.400000, 2.100000, 1.900000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-01-01 00:00:00', 4.262500, 4.024700, 2.780200, 2.675300, 1.276500, 1.171700);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-02-01 00:00:00', 3.923000, 3.442000, 2.887200, 2.345800, 1.035800, 1.096200);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-03-01 00:00:00', 6.793200, 6.777800, 5.114000, 5.217400, 1.676000, 1.560200);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-04-01 00:00:00', 8.121700, 8.190400, 6.385800, 6.478600, 1.730100, 1.706200);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-05-01 00:00:00', 9.600000, 10.200000, 7.700000, 8.200000, 1.900000, 2.000000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-06-01 00:00:00', 8.600000, 8.400000, 6.400000, 6.200000, 2.200000, 2.200000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-07-01 00:00:00', 9.000000, 8.400000, 6.800000, 6.000000, 2.300000, 2.400000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-08-01 00:00:00', 9.900000, 10.100000, 7.200000, 7.300000, 2.700000, 2.800000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-09-01 00:00:00', 12.700000, 12.100000, 10.000000, 9.400000, 2.700000, 2.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-10-01 00:00:00', 14.600000, 13.800000, 11.600000, 11.100000, 2.900000, 2.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-11-01 00:00:00', 17.300000, 16.900000, 13.500000, 13.800000, 3.800000, 3.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2018-12-01 00:00:00', 21.400000, 22.500000, 17.900000, 19.300000, 3.600000, 3.200000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-01-01 00:00:00', 9.100000, 9.600000, 6.700000, 7.500000, 2.400000, 2.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-02-01 00:00:00', 5.900000, 5.300000, 4.400000, 4.000000, 1.500000, 1.300000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-03-01 00:00:00', 12.800000, 12.600000, 10.000000, 9.600000, 2.800000, 3.000000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-04-01 00:00:00', 10.200000, 9.700000, 8.200000, 7.100000, 2.000000, 2.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-05-01 00:00:00', 11.200000, 10.400000, 9.400000, 8.300000, 1.800000, 2.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-06-01 00:00:00', 13.400000, 15.200000, 11.300000, 12.900000, 2.000000, 2.200000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-07-01 00:00:00', 8.400000, 8.000000, 6.500000, 6.100000, 2.000000, 1.900000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-08-01 00:00:00', 8.700000, 8.500000, 7.400000, 6.900000, 1.400000, 1.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-09-01 00:00:00', 8.900000, 8.000000, 7.400000, 6.300000, 1.500000, 1.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-10-01 00:00:00', 9.500000, 7.500000, 7.800000, 5.900000, 1.600000, 1.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-11-01 00:00:00', 11.000000, 9.500000, 9.600000, 8.100000, 1.400000, 1.400000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2019-12-01 00:00:00', 14.900000, 16.300000, 12.900000, 14.000000, 1.900000, 2.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-01-01 00:00:00', 4.000000, 4.400000, 3.000000, 3.300000, 1.300000, 1.300000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-02-01 00:00:00', 0.995100, 1.290800, 0.834200, 1.068000, 0.160900, 0.222800);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-03-01 00:00:00', 5.000000, 5.300000, 3.800000, 4.000000, 1.100000, 1.300000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-04-01 00:00:00', 8.000000, 7.200000, 5.800000, 5.100000, 2.260000, 2.040000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-05-01 00:00:00', 8.400000, 8.200000, 6.300000, 6.400000, 2.100000, 1.800000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-06-01 00:00:00', 10.200000, 10.400000, 7.900000, 8.200000, 2.300000, 2.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-07-01 00:00:00', 10.000000, 9.800000, 7.900000, 7.800000, 2.100000, 1.900000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-08-01 00:00:00', 10.600000, 10.900000, 8.200000, 8.800000, 2.100000, 2.400000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-09-01 00:00:00', 13.600000, 13.800000, 10.700000, 11.200000, 2.900000, 2.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-10-01 00:00:00', 16.700000, 16.000000, 14.100000, 13.300000, 2.600000, 2.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-11-01 00:00:00', 19.800000, 20.000000, 16.400000, 16.700000, 3.300000, 3.300000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2020-12-01 00:00:00', 23.500000, 24.800000, 20.300000, 21.100000, 3.200000, 3.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-01-01 00:00:00', 19.400000, 17.900000, 16.600000, 15.100000, 2.800000, 2.900000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-02-01 00:00:00', 12.400000, 11.000000, 10.700000, 9.200000, 1.600000, 1.700000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-03-01 00:00:00', 21.600000, 22.600000, 18.200000, 19.000000, 3.400000, 3.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-04-01 00:00:00', 21.600000, 20.600000, 16.900000, 15.800000, 3.400000, 3.500000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-05-01 00:00:00', 21.700000, 21.700000, 20.400000, 21.100000, 3.600000, 3.800000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-06-01 00:00:00', 24.800000, 25.600000, 20.400000, 21.100000, 4.300000, 4.400000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-07-01 00:00:00', 30.900000, 32.100000, 23.800000, 25.100000, 5.600000, 5.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-08-01 00:00:00', 30.900000, 32.100000, 25.200000, 26.500000, 5.600000, 5.600000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-09-01 00:00:00', 35.300000, 35.700000, 29.100000, 29.600000, 6.200000, 6.100000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-10-01 00:00:00', 39.700000, 38.300000, 32.900000, 31.600000, 6.820000, 6.710000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-11-01 00:00:00', 45.760000, 44.960000, 37.200000, 36.100000, 8.460000, 8.860000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2021-12-01 00:00:00', 51.800000, 53.100000, 43.400000, 44.800000, 8.350000, 8.240000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-01-01 00:00:00', 45.200000, 43.100000, 36.700000, 34.700000, 8.440000, 8.540000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-02-01 00:00:00', 36.900000, 33.400000, 28.500000, 25.800000, 8.250000, 7.530000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-03-01 00:00:00', 46.500000, 48.400000, 37.600000, 39.500000, 8.850000, 8.790000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-04-01 00:00:00', 31.200000, 29.900000, 24.200000, 23.100000, 6.900000, 6.800000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-05-01 00:00:00', 46.600000, 44.700000, 36.400000, 34.700000, 10.200000, 10.000000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-06-01 00:00:00', 59.000000, 59.600000, 46.600000, 47.600000, 12.300000, 12.000000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-07-01 00:00:00', 61.700000, 59.300000, 47.200000, 45.700000, 14.400000, 13.500000);
INSERT INTO `VehicleSales` (`dtime`, `neProdVol`, `neSalesVol`, `elecProdVol`, `elecSalesVol`, `hybProdVol`, `hybSalesVol`) VALUES ('2022-08-01 00:00:00', 69.100000, 66.600000, 53.600000, 52.200000, 15.500000, 14.400000);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
