/*
 Navicat Premium Data Transfer

 Source Server         : 172.31.179.131
 Source Server Type    : MySQL
 Source Server Version : 80027
 Source Host           : 172.31.179.131:53306
 Source Schema         : test_data

 Target Server Type    : MySQL
 Target Server Version : 80027
 File Encoding         : 65001

 Date: 24/02/2025 11:46:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Gasoline
-- ----------------------------
DROP TABLE IF EXISTS `Gasoline`;
CREATE TABLE `Gasoline` (
  `dtime` datetime NOT NULL COMMENT '时间\\汽油零售价格',
  `g98` double(20,6) NOT NULL COMMENT '98号汽油，全国 (元/升)',
  `g95` double(20,6) NOT NULL COMMENT '95号汽油，全国 (元/升)',
  `g92` double(20,6) NOT NULL COMMENT '92号汽油，全国 (元/升)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='油价变动记录';

-- ----------------------------
-- Records of Gasoline
-- ----------------------------
BEGIN;
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2019-09-01 00:00:00', 7.849722, 7.102621, 6.629812);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2019-10-01 00:00:00', 7.872569, 7.153602, 6.684731);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2019-11-01 00:00:00', 7.937465, 7.199382, 6.717204);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2019-12-01 00:00:00', 8.017812, 7.277554, 6.790995);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-01-01 00:00:00', 8.209858, 7.476673, 6.964096);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-02-01 00:00:00', 6.908123, 6.955345, 6.952920);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-03-01 00:00:00', 6.990298, 6.319722, 5.895778);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-04-01 00:00:00', 6.529808, 5.892772, 5.490702);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-05-01 00:00:00', 6.526369, 5.899708, 5.503472);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-06-01 00:00:00', 5.764050, 5.712058, 5.699128);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-07-01 00:00:00', 6.706345, 6.071991, 5.670027);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-08-01 00:00:00', 6.750284, 6.105034, 5.705146);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-09-01 00:00:00', 6.667803, 6.004812, 5.603280);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-10-01 00:00:00', 7.865833, 7.144803, 6.669588);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-11-01 00:00:00', 7.940938, 7.202823, 6.720376);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2020-12-01 00:00:00', 6.833258, 6.158409, 5.751247);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-01-01 00:00:00', 7.141061, 6.434857, 6.010108);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-02-01 00:00:00', 7.375909, 6.662832, 6.227213);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-03-01 00:00:00', 7.898068, 7.154803, 6.678602);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-04-01 00:00:00', 7.802595, 7.059283, 6.591729);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-05-01 00:00:00', 7.925972, 7.181801, 6.712124);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-06-01 00:00:00', 8.149482, 7.400898, 6.919005);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-07-01 00:00:00', 8.388182, 7.597366, 7.103297);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-08-01 00:00:00', 8.259577, 7.491962, 7.005314);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-09-01 00:00:00', 8.258258, 7.494086, 7.010054);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-10-01 00:00:00', 8.687121, 7.903065, 7.393423);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-11-01 00:00:00', 8.850631, 8.063172, 7.531667);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2021-12-01 00:00:00', 8.334975, 7.571416, 7.066290);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-01-01 00:00:00', 8.618258, 7.797823, 7.274328);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-02-01 00:00:00', 9.060985, 8.265323, 7.717760);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-03-01 00:00:00', 9.872247, 8.842419, 8.273602);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-04-01 00:00:00', 9.826414, 9.125699, 8.523629);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-05-01 00:00:00', 10.043838, 9.168817, 8.563172);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-06-01 00:00:00', 10.753788, 9.775202, 9.133559);
INSERT INTO `Gasoline` (`dtime`, `g98`, `g95`, `g92`) VALUES ('2022-07-01 00:00:00', 10.160859, 9.400457, 8.774113);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
